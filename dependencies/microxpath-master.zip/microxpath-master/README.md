# microxpath
XPath like XML navigator with a tiny memory footprint for the Arduino platform. The parser only uses a few bytes of memory.
